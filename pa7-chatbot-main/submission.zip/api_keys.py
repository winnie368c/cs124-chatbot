# Insert your TOGETHER_API_KEY and remove '.example' from the file name
TOGETHER_API_KEY="d2c14a8c110cbcb537b91845b8fa0465c5d60b4e57a06decf4af5d3d023482ea"
